strongpw() {
    [[ "$1" != "" ]] || return
    one_arg=0
    (($#==1)) && one_arg=1
    read -rs -p 'Encryption key: ' key
    [[ "$key" != "" ]] || return
    echo ''
    while [[ "$1" != "" ]]
    do
        echo -n "Password for $1: " # line break
        if (($one_arg==1)) ; then
            echo -n "$key:$1" | sha256sum | perl -ne "s/([0-9a-f]{2})/print chr hex \$1/gie" | base64 | tr +/ Ea | cut -b 1-20 | gclip
            echo '(in clipboard)'
        else
            echo -n "$key:$1" | sha256sum | perl -ne "s/([0-9a-f]{2})/print chr hex \$1/gie" | base64 | tr +/ Ea | cut -b 1-20
        fi
        shift
    done
    echo -n 'Verification code: '
    echo -n ":$key:" | sha256sum | perl -ne "s/([0-9a-f]{2})/print chr hex \$1/gie" | base64 | tr +/ Ea | cut -b 1-20
}
